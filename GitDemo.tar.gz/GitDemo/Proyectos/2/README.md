# Project 1

This is the project, first cloned using `git clone ../Repo/1.git` :

```
$ cd GitDemo/Proyectos
$ git clone ../Repo/1.git
Cloning into '1'...
warning: You appear to have cloned an empty repository.
done.
$
```

So I updated the documentation. Now, I add it to my working copy, and commit all the changes.

```
$ git add README.md
git commit -a
[master (root-commit) 5ad6877] Added the documentation
 1 file changed, 92 insertions(+)
 create mode 100644 README.md
$ git status
On branch master
Your branch is based on 'origin/master', but the upstream is gone.
  (use "git branch --unset-upstream" to fixup)

nothing to commit, working tree clean
$
```

See what happen here. It says that ... I'm ahead from the remote by 1 commit. That's it, my
working copy is more updated than remote. So let's check in the remote how it is. As you 
expect, the remote isn't updated.


```
$cd /Archive/Src/GitDemo/Repo/1
$ git status
On branch master
nothing to commit, working tree clean
$
```

Need to get some info about the remote?

```
$ git remote show origin
* remote origin
  Fetch URL: /Archive/Src/GitDemo/Proyectos/../Repo/1.git
  Push  URL: /Archive/Src/GitDemo/Proyectos/../Repo/1.git
  HEAD branch: (unknown)
  Local branch configured for 'git pull':
    master merges with remote master
$    
```

Well, time to sync our working copy with the remote one.

```
$ git push origin master
Counting objects: 3, done.
Delta compression using up to 8 threads.
Compressing objects: 100% (2/2), done.
Writing objects: 100% (3/3), 1.02 KiB | 1.02 MiB/s, done.
Total 3 (delta 0), reused 0 (delta 0)
To /Archive/Src/GitDemo/Proyectos/../Repo/1.git
 * [new branch]      master -> master
$
```

All done. We have commited our changes to the remote.
All commands work here.


Need to see what is changed from working copy to remote ?

```
$git diff origin/master master
diff --git a/README.md b/README.md
index b2a25e9..b32cc58 100644
--- a/README.md
+++ b/README.md
@@ -1 +1,16 @@
 # Project 1
+
+This is the project, first cloned using `git clone ../Repo/1` :
+
+```
+$ cd GitDemo/Proyectos
+$ git clone ../Repo/1
+Cloning into '1'...
+done.
+```
+
+So I updated the documentation. Now, I add it to my working copy:
+
+```
+$ git add README.md
+```
```

if we what to check the tree, just checkout the working copy, with (-n no checkout, only info)
**line added in clone 2**

Use annotated tags, instead lightweight

`git tag -a v1.4 -m "my version 1.4"`
 `git log --pretty=oneline`
 `git push origin v1.5`
 `git tag -d v1.4-lw`
 `git push origin --delete <tagname>`
 `git checkout v2.0.0`
`git checkout -b version2 v2.0.0`

After adding one line in the clone #2 and commit it (and pushing!) I go to project 1,
and commit the README.md (with more commands). When I try to push it:

```
$ git push origin master
To /Archive/Src/GitDemo/Proyectos/../Repo/1.git
 ! [rejected]        master -> master (fetch first)
error: failed to push some refs to '/Archive/Src/GitDemo/Proyectos/../Repo/1.git'
hint: Updates were rejected because the remote contains work that you do
hint: not have locally. This is usually caused by another repository pushing
hint: to the same ref. You may want to first integrate the remote changes
hint: (e.g., 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
```

Long history short: Somebody has updated the project, so before doing your `push`
you have to `pull` the changes first. So let's go:

```
$ git pull origin master
Merge branch 'master' of /Archive/Src/GitDemo/Proyectos/../Repo/1
  
# Please enter a commit message to explain why this merge is necessary,
# especially if it merges an updated upstream into a topic branch.
#
# Lines starting with '#' will be ignored, and an empty message aborts
# the commit.
remote: Counting objects: 3, done.
remote: Compressing objects: 100% (2/2), done.
remote: Total 3 (delta 1), reused 0 (delta 0)
Unpacking objects: 100% (3/3), done.
From /Archive/Src/GitDemo/Proyectos/../Repo/1
 * branch            master     -> FETCH_HEAD
   1393c5b..b391c9a  master     -> origin/master
Auto-merging README.md
Merge made by the 'recursive' strategy.
 README.md | 1 +
 1 file changed, 1 insertion(+)
 $
```

Let's explain this. When you do the `pull`, it wants to `merge` the contents (two guys touched the same file)
so, git creates a merge, and ask for a comment. Default one is fine, but you can document it (e.g. merge after
version change ...). Then, it tells you what happen here. If there are any `conflicts`they should be resolved
here, let's see.

*conflict line from 2*

Whe create manually a conflict, so when we pull  the changes:

```
$ git pull 
remote: Counting objects: 3, done.
remote: Compressing objects: 100% (2/2), done.
remote: Total 3 (delta 1), reused 0 (delta 0)
Unpacking objects: 100% (3/3), done.
From /Archive/Src/GitDemo/Proyectos/../Repo/1
   067511d..254a4ff  master     -> origin/master
Auto-merging README.md
CONFLICT (content): Merge conflict in README.md
Automatic merge failed; fix conflicts and then commit the result.
```

So edit the file, add the `README.md` file, add a merge message, and push it. That's all.
