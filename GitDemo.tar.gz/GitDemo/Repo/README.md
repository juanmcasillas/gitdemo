# Remote Master Repo

Create this directory in a shared drive (e.g. DropBox, OneDrive) and init a **bare** repo

```
$ cd Repos
$ git init --bare 1.git
$
```

This creates a EMPTY Repo. We have to upload things to it. So if it is the first time we
work on the repo, just clone it, and add content.

```
$ git clone ../Repo/1.git
Cloning into '1'...
warning: You appear to have cloned an empty repository.
done.
$
```

